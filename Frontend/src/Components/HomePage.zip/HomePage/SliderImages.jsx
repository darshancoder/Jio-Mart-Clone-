export const countries = [
    {
        image: "https://www.jiomart.com/images/cms/aw_rbslider/slides/1670993067_Web_Mumbai_PremiumFruits.jpg",
    },
    {
        image: "https://www.jiomart.com/images/cms/aw_rbslider/slides/1671387134_Iphone_web.jpg",
    },
    {
        image: "https://www.jiomart.com/images/cms/aw_rbslider/slides/1671387441_Accessories-fiesta-1680.jpg",
    },
    {
        image: "https://www.jiomart.com/images/cms/aw_rbslider/slides/1671374198_Mumbai.jpg",
    },
    {
        image: "https://www.jiomart.com/images/cms/aw_rbslider/slides/1671387898_Hot-Deals-on-Furniture_1680-x-320.jpg",
    },
    {
        image: "https://www.jiomart.com/images/cms/aw_rbslider/slides/1671388138_Handwoven_.jpg"
    },
    {
        image: "https://www.jiomart.com/images/cms/aw_rbslider/slides/1671387323_Bindass_web.jpg"
    }
  ];